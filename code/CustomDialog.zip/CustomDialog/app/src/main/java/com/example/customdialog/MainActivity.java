package com.example.customdialog;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        showCustomDialog();
    }

    private void showCustomDialog() {
        Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.dialog_custom);

        EditText editTextName = dialog.findViewById(R.id.editTextName);
        EditText editTextEmail = dialog.findViewById(R.id.editTextEmail);
        EditText editTextContact = dialog.findViewById(R.id.editTextContact);
        Button buttonSubmit = dialog.findViewById(R.id.buttonSubmit);

        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = editTextName.getText().toString().trim();
                String email = editTextEmail.getText().toString().trim();
                String contact = editTextContact.getText().toString().trim();

                if(name.isEmpty() || email.isEmpty() || contact.isEmpty()){
                    Toast.makeText(MainActivity.this, "Fill All details", Toast.LENGTH_SHORT).show();
                }
                else {

                    Intent intent = new Intent(MainActivity.this, DisplayActivity.class);

                    Bundle bundle = new Bundle();
                    bundle.putString("name", name);
                    bundle.putString("email", email);
                    bundle.putString("contact", contact);
                    intent.putExtras(bundle);

                    startActivity(intent);
                    dialog.dismiss();
                }
            }
        });

        dialog.show();
    }
}